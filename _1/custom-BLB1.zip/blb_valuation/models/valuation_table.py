# -*- coding: utf-8 -*-

from odoo import models, fields, api, tools, _
from datetime import datetime
from datetime import date
from dateutil.relativedelta import relativedelta
from datetime import timedelta
from odoo.exceptions import Warning as UserError
from odoo.exceptions import ValidationError
from odoo.exceptions import AccessDenied, UserError
from odoo.tools.parse_version import parse_version
from odoo.tools.misc import topological_sort
import json



class counties(models.Model):
    _name = 'blb_valuation.counties'
    _description = 'BLB - Counties'
    _inherit = ['mail.thread', 'mail.activity.mixin']
    _order = 'name asc'

    name = fields.Char(string='County', required=True)

    _sql_constraints = [
        ('name',
         'UNIQUE(name)',
         "The County should be Unique!")
    ]

class districts(models.Model):
    _name = 'blb_valuation.districts'
    _description = 'BLB - Districts'
    _inherit = ['mail.thread', 'mail.activity.mixin']
    _order = 'county_id,name asc'

    county_id = fields.Many2one('blb_valuation.counties', string='County', required=True)
    name = fields.Char(string='District', required=True)

    _sql_constraints = [
        ('name',
         'UNIQUE(name)',
         "The District should be Unique!")
    ]

class subcounties(models.Model):
    _name = 'blb_valuation.subcounties'
    _description = 'BLB - Sub-Counties'
    _inherit = ['mail.thread', 'mail.activity.mixin']
    _order = 'county_id,district_id,name asc'

    county_id = fields.Many2one('blb_valuation.counties', string='County', required=True)
    district_id = fields.Many2one('blb_valuation.districts', string='District', required=True, domain="[('county_id', '=', county_id)]")
    name = fields.Char(string='Sub-County', required=True)

    _sql_constraints = [
        ('name',
         'UNIQUE(name)',
         "The Sub-County should be Unique!")
    ]


class parishes(models.Model):
    _name = 'blb_valuation.parishes'
    _description = 'BLB - Parishes'
    _inherit = ['mail.thread', 'mail.activity.mixin']
    _order = 'county_id,district_id,subcounty_id,name asc'

    county_id = fields.Many2one('blb_valuation.counties', string='County', required=True)
    district_id = fields.Many2one('blb_valuation.districts', string='District', required=True, domain="[('county_id', '=', county_id)]")
    subcounty_id = fields.Many2one('blb_valuation.subcounties', string='Sub-County', required=True, domain="[('district_id', '=', district_id)]")
    name = fields.Char(string='Parish', required=True)

    _sql_constraints = [
        ('name',
         'UNIQUE(name)',
         "The Parish should be Unique!")
    ]

class villages(models.Model):
    _name = 'blb_valuation.villages'
    _description = 'BLB - Villages'
    _inherit = ['mail.thread', 'mail.activity.mixin']
    _order = 'county_id,district_id,subcounty_id,parish_id,name asc'

    county_id = fields.Many2one('blb_valuation.counties', string='County', required=True)
    district_id = fields.Many2one('blb_valuation.districts', string='District', required=True, domain="[('county_id', '=', county_id)]")
    subcounty_id = fields.Many2one('blb_valuation.subcounties', string='Sub-County', required=True, domain="[('district_id', '=', district_id)]")
    parish_id = fields.Many2one('blb_valuation.parishes', string='Parish', required=True, domain="[('subcounty_id', '=', subcounty_id)]")
    name = fields.Char(string='Village', required=True)

    _sql_constraints = [
        ('name',
         'UNIQUE(name)',
         "The village should be Unique!")
    ]


class landuse_types(models.Model):
    _name = 'blb_valuation.landuse_types'
    _description = 'BLB - Types of Land Use'
    _inherit = ['mail.thread', 'mail.activity.mixin']
    _order = 'name asc'

    name = fields.Char(string='Land Use', required=True)

    _sql_constraints = [
        ('name',
         'UNIQUE(name)',
         "The Land Use should be Unique!")
    ]




#####################################################################################
## ***
## ***  Valuation Table
## ***
#####################################################################################

class valuation_table(models.Model):
    _name = 'blb_valuation.valuation_table'
    _description = 'BLB - Valuation Table'
    _inherit = ['mail.thread', 'mail.activity.mixin']
    _order = 'name desc'

    name = fields.Char(string="Valuation Table", readonly=True, compute="_compute_name", store=True)
    county_id = fields.Many2one('blb_valuation.counties', string='County', required=True)
    district_id = fields.Many2one('blb_valuation.districts', string='District', required=True, domain="[('county_id', '=', county_id)]")
    subcounty_id = fields.Many2one('blb_valuation.subcounties', string='Sub-County', required=True, domain="[('district_id', '=', district_id)]")
    parish_id = fields.Many2one('blb_valuation.parishes', string='Parish', required=True, domain="[('subcounty_id', '=', subcounty_id)]")
    village_id = fields.Many2one('blb_valuation.villages', string='village', required=True, domain="[('parish_id', '=', parish_id)]")
    landuse_valuation_ids = fields.One2many('blb_valuation.landuse_valuation', 'valuation_table_id', string='Land Use Valuations')

    #Compute Name
    @api.depends('county_id','district_id','subcounty_id','parish_id','village_id')
    def _compute_name(self):
        rec_name = ''
        for rec in self:
            if rec.county_id and rec.district_id and rec.subcounty_id and rec.parish_id and rec.village_id:
                rec_name = str(rec.county_id.name) + "/" + str(rec.district_id.name) + "/" + str(rec.subcounty_id.name) + "/" + str(rec.parish_id.name) + "/" + str(rec.village_id.name)
            rec.name = rec_name
        return rec_name

    _sql_constraints = [
        ('name',
         'UNIQUE(name)',
         "The Table Record should be Unique!")
    ]


class landuse_valuation(models.Model):
    _name = 'blb_valuation.landuse_valuation'
    _description = 'BLB - Land Use Valuation'
    _inherit = ['mail.thread', 'mail.activity.mixin']
    _order = 'name asc'

    name = fields.Char(string="Land Use Valuation", readonly=True, compute="_compute_name", store=True)
    landuse_type_id = fields.Many2one('blb_valuation.landuse_types', string="Type of Land Use", required=True)
    from_range = fields.Monetary(string="From", required=True)
    to_range = fields.Monetary(string="To", required=True)
    currency_id = fields.Many2one('res.currency', 'Currency', readonly=True, required=True, default=lambda self: self.env.user.company_id.currency_id.id)
    valuation_table_id = fields.Many2one('blb_valuation.valuation_table', string='Valuation Table')

    #Compute Name
    @api.depends('landuse_type_id','from_range','to_range')
    def _compute_name(self):
        rec_name = ''
        for rec in self:
            if rec.landuse_type_id and rec.from_range and rec.to_range:
                rec_name = str(rec.landuse_type_id.name) + " (" + str(rec.from_range) + " - " + str(rec.to_range) + ")"
            rec.name = rec_name
        return rec_name

    #Check whether condition_amount allocated does not exceed grant_salary_contribution 
    @api.onchange('to_range')
    def _onchange_to_range(self):
        for rec in self:
            if rec.from_range > rec.to_range:
                raise ValidationError(_( "From: " + str(rec.from_range) + " is greate thant To: " + str(rec.to_range) ))

    #Create Put together the Details
    @api.model
    def create(self, vals):
        #Check from and to values
        from_range = int(vals['from_range'])
        to_range = int(vals['to_range'])
        if from_range > to_range:
            raise ValidationError(_( "From: " + str(from_range) + " is greate thant To: " + str(to_range) ))
        res = super(landuse_valuation, self).create(vals)
        return res

