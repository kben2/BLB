<?php

require 'smsGateway/autoload.php';

use SMSGatewayMe\Client\ApiClient;
use SMSGatewayMe\Client\Configuration;
use SMSGatewayMe\Client\Api\MessageApi;
use SMSGatewayMe\Client\Model\SendMessageRequest;


// Configure client
$config = Configuration::getDefaultConfiguration();
$config->setApiKey('Authorization', 'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiJhZG1pbiIsImlhdCI6MTY0MDAxNDc4NSwiZXhwIjo0MTAyNDQ0ODAwLCJ1aWQiOjkxODY4LCJyb2xlcyI6WyJST0xFX1VTRVIiXX0.vnFn6VgfdbqEgbsiEyWHRi_gzi-NeGBPWaf4NolP56M');
$apiClient = new ApiClient($config);
$messageClient = new MessageApi($apiClient);


// Sending a SMS Message
$phone_number = $argv[1];
$message = $argv[2];

$sendMessageRequest = new SendMessageRequest([
    'phoneNumber' => $phone_number,
    'message' => $message,
    'deviceId' => 126678
]);

$sendMessages = $messageClient->sendMessages([ $sendMessageRequest ]);
//print_r($sendMessages);



?>