# -*- coding: utf-8 -*-
{
    'name': "BLB - Map View",

    'summary': "BLB - Map View",
    'description': """
        BLB - Map View
    """,

    'version': '0.1',
    'depends': ['blb_locate_query'],
    'data': [
        "views/assets.xml",
        "views/data.xml"
    ],
 
    'installable': True,
    'auto_install': True
}