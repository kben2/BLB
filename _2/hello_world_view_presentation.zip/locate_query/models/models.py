# -*- coding: utf-8 -*-

from odoo import models, fields, api, _
from datetime import datetime
from datetime import date
from dateutil.relativedelta import relativedelta
from odoo.exceptions import Warning as UserError
from odoo.exceptions import ValidationError
import string
import random
import csv
from ezdxf.enums import TextEntityAlignment
from ezdxf import zoom,units
import math





class locate_query(models.Model):
    _name = 'client.locate_query'
    _description = 'Locate Query'
    
    latitude = fields.Char(string="Latitude")
    longitude = fields.Char(string="Longitude")
    id = fields.Char(string="ID")
    name = fields.Char(string="Name")
    #coordinate_z = fields.Char(string="Drawing name")
    # check_wetland = fields.Char(string="Wetland")
    # check_surveyed = fields.Char(string="Surveyed Kibanja")
    # check_blbland = fields.Char(string="BLB Land")


    

